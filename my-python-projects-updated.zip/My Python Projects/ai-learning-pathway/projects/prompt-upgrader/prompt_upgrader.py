#!/usr/bin/env python3
"""
A simple prompt upgrader.

It takes a poorly worded or vague prompt and returns a clearer version.
The heuristics here are simple: we expand abbreviations, add context words,
and encourage specificity. This is meant as a starting point for your AI learning journey.
"""

import sys
from typing import List


def upgrade_prompt(original: str) -> str:
    """
    Upgrade a given prompt to make it clearer and more specific.

    Parameters
    ----------
    original : str
        The original user prompt.

    Returns
    -------
    str
        A refined prompt with clearer instructions.
    """
    prompt = original.strip()
    if not prompt:
        return "Provide a clear, specific question or instruction."

    # Normalize case
    normalized = prompt.capitalize()

    # Add context to very short prompts
    words = normalized.split()
    if len(words) < 4:
        normalized = f"Please provide more details about: {normalized}."

    # Encourage the user to specify examples or constraints
    refined = (
        f"Rewrite the following request as a clear, specific question or instruction "
        f"that includes necessary details and desired output format:\n\n{normalized}"
    )
    return refined


def main(args: List[str]) -> None:
    """Run the prompt upgrader from the command line."""
    if not args:
        print("Usage: python prompt_upgrader.py \"your prompt\"")
        return
    original_prompt = " ".join(args)
    print(upgrade_prompt(original_prompt))


if __name__ == "__main__":
    main(sys.argv[1:])
