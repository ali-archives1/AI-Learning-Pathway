# Prompt Upgrader

This mini‑project helps turn a vague or poorly worded question into a clearer one.

## Usage

Run the script with a text prompt:

```sh
python prompt_upgrader.py "tell me about ai"
```

The script prints an improved version of the prompt.
